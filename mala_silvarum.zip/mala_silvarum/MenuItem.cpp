//
//MenuItem.cpp
//
//

#include <iostream>
#include "MenuItem.h"
using namespace std;

MenuItem::MenuItem(char c, std::string s)
{
    mCommandCharacter = c;
    mTitle = s;
}


ostream& operator<<(ostream& oS, MenuItem& menuitem)
{
  oS<< menuitem.mCommandCharacter << ") " << menuitem.mTitle <<endl;
  return oS;
}