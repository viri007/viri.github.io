//
//
//Menu class method implementations
//
//

#include <iostream>
#include "Menu.h"
using namespace std;

Menu::Menu (MenuItem itemsarray[])
{
    for (int a=0; a< 3; a++)
    mItems.push_back(itemsarray[a]); 
}



std::vector <MenuItem> Menu::getItems()
{
  return mItems;
}


char Menu::promptUser ()
{
char prompt;
  std::cout << "Enter Choice> ";
  
  std::cin >> prompt;

  //Compare the input to the menu items' prompt characters

  for (int x= 0; x< mItems.size(); x++)
    if (prompt == mItems[x].getCommandChar())
      return prompt;
  return -1;
}

//Overload the << operator to display the menu
ostream& operator<<(ostream& o, Menu& todisplay)
{
  vector <MenuItem> menuitems = todisplay.getItems();
  o<<"\n= = = = = = = =  MALA SILVARUM  = = = = = = = =\n"<<endl;
  o<< "MENU" <<endl;
  o<< "====" <<endl;
  for (MenuItem i : menuitems) 
    o<< i;
  return o;
}