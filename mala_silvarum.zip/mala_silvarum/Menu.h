//
//Simple menu class to build a menu
//using an vector of MenuItems
//

#ifndef _MENU_H_
#define _MENU_H_

#include <iostream>
#include <vector>
#include "MenuItem.h"




class Menu 
{
    public:
        Menu(MenuItem itemsarray[]);
        void display();
        std::vector <MenuItem> getItems();
        char promptUser();
        friend std::ostream& operator<<(std::ostream& o, Menu& todisplay);

    private:
        std::vector<MenuItem> mItems;
};
#endif