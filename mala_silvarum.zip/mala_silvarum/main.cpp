//
//main.cpp
//

#include <iostream>
#include <fstream>
#include "Menu.h"
#include "MenuItem.h"
#include "Game.h"
using namespace std;


int main(int argc,char *argv[]) 
{

    MenuItem items[3] = {MenuItem('1', "Start"), MenuItem('2', "Extras"), MenuItem('3', "Quit") };

    //Creating the menu with items in array
    Menu mainmenu(items);
    bool continue_bool = true;
    char promptedChar;
    
    Game g;

    while (continue_bool == true) 
    {
        //Show user the menu
        cout<< mainmenu;
        //Prompt the user for a character
        promptedChar = mainmenu.promptUser();
        switch (promptedChar) {
            case '1':
                cout <<"Press enter to advance trough the game, and make your choices carefully."<<endl;
                cout<<"Press q at any choice to quit the game and start over"<<endl;
                cout << "\n...PROCEED WITH CAUTION...\n"<<endl;
                g.startgame();
                break;
            case '2':
                if (g.isComplete()){
                    cout<<"\n==== EXTRAS ======\n"<<endl;
                    ifstream extras;
                    extras.open("extras_info.txt");
                    if (extras.is_open()){
                        cout<<extras.rdbuf();
                    }

                    break;
                }
                else{
                    cout<<"Can't access this yet" <<endl;
                    break;
                }
            case '3':
                cout <<"QUITTING" <<endl;
                continue_bool = false;
                break;
        }
    } 
}