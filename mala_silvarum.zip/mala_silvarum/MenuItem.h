//
//
//MeniItem class to create MenuItems for the Menu
//
//

#ifndef _MENUITEM_H_
#define _MENUITEM_H_
#include <iostream>


class MenuItem {
    public:
        MenuItem(char c,std::string);
        char getCommandChar() { return mCommandCharacter; }
        std::string getTitle() { return mTitle; }
        friend std::ostream& operator<<(std::ostream& oS, MenuItem& mi);

    protected:
        char mCommandCharacter;
        std::string mTitle;
};      
#endif