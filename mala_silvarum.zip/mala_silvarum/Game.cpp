//Game.cpp
//
//This is where the the game runs and ends
//
//

#include <iostream>
#include <time.h>

#include "Game.h"

using namespace std;


//
//This path signifies a game over and takes use back to the main menu
//
void Game::gameoverpath_car() {
    std::cout<<"As you run, hard, heavy footsteps follow\n\n\n\n"<<endl;
    this->pauseprint(2500);
    std::cout<<"Much faster than you\n\n\n"<<endl;
    this->pauseprint(2400);
    std::cout<<"Closer\n\n"<<endl;
    this->pauseprint(2000);
    std::cout<<"You're on the ground\n"<<endl;
    this->pauseprint(1000);
    std::cout<<"Before you can turn round, sharp jaws enclose you."<<endl;
    this->pauseprint(2500);
    char game_over;
    std::cout<<"====GAME OVER====\n"<<endl;
    std::cout<<"====Press q to go back to main menu===="<<endl;
    cin >>game_over;
}

//
//This path is the other way to get a game over, and also takes the user
//back to the main menu
//
void Game::gameoverpath_forest(){
    std::cout<<"Slivers of moonlight on the dry leaves are the only light you can see."<<endl;
    this->enter();
    std::cout<<"The forest's night breathing is heavy and packed with small rustling sounds with no origin that make your skin crawl."<<endl;
    this->enter();
    std::cout<<"You hear light footsteps nearby\n\n\n"<<endl;
    this->pauseprint(2300);
    std::cout<<"They get closer\n\n"<<endl;
    this->pauseprint(2100);
    std::cout<<"Closer\n"<<endl;
    std::cout<<"Before you can turn around, sharp jaws enclose you."<<endl;
    this->pauseprint(2500);
    char game_over;
    std::cout<<"====GAME OVER====\n"<<endl;
    std::cout<<"====Press q to go back to main menu===="<<endl;
    cin >>game_over;  
}

//
//This path is the only way to finish the game
//At the end, it updates the game's completed status
//Once this path executes, the user can access the extras
//
void Game::forestpath_path(){
    std::cout<<"The phone is quiet, and so is the path."<<endl;
    this->Game::enter();
    std::cout<<"Your footsteps squelch in the mud, over and over again."<<endl; 
    this->Game::enter();
    std::cout<<"You eventually reach a medium-sized cabin that is mirculously still standing."<<endl;
    this->Game::enter();
    std::cout<<"The trees\' shadows shroud the cabin with omens: you're curious."<<endl;
    this->Game::enter();
    std::cout<<"Most of the windows are shattered, the roof has a large hole, and the wood is chipping away."<<endl;
    this->Game::enter();
    char entercabin;
    std::cout<<"a) Enter the cabin"<<endl;
    std::cout<<"Your choice: ", cin >>entercabin;

    switch (entercabin){
        case 'q':
            std::cout<<"QUITTING"<<endl;
            return;
        case 'a':
            std::cout<<"Although no light shone from the outside, the cabin is well-lit inside."<<endl;
            this->Game::enter();
            std::cout<<"It looks nothing like it did from the outside..."<<endl;
            this->Game::enter();
            std::cout<<"Candles light up a small living room where a dark green couch sits."<<endl;
            this->Game::enter();
            std::cout<<"Before you get tool look around any longer, a young girl emerges from the hallway."<<endl;
            this->Game::enter();
            std::cout<<"Her clothes are clean and her hair is neat in a ponytail."<<endl; 
            this->Game::enter();
            std::cout<<"'You\'re here! Quick! We need to get out of here before she comes back!'"<<endl;
            this->Game::enter();
            std::cout<<"A cold breeze enters the house with a creak of the door, along with a woman."<<endl;
            this->Game::enter();
            std::cout<<"She has long, black hair with streaks of gray. Her ominous entrance does not match her kind looks at all."<<endl; 
            this->Game::enter();
            std::cout<<"'Are we having a visitor today?' she asks."<<endl;
            this->Game::enter();
            std::cout<<"Everyone looks at each other until you\'re finally able to speak."<<endl;
            char whoareyou;
            std::cout<<"a) Who are you?"<<endl;
            std::cout<<"Your choice: ", cin>> whoareyou, std::cout<<"\n"<<endl;

            switch (whoareyou){
                case 'a':
                    std::cout<<"'Names don\'t matter here, young heart'"<<endl;
                    this->Game::enter();
                    std::cout<<"'You must be here for the girl. But there's no need for her to be saved anymore. She's here now and she's safe'"<<endl;    
                    this->Game::enter();  
                    std::cout<<"The girl speaks for the first time, and you wish she hadn\'t."<<endl;
                    this->Game::enter();
                    std::cout<<"'The one who\'s not safe now is you'"<<endl;
                    this->Game::enter();
                    std::cout<<"You start to step back towards the door, but when you turn around, you find that it's been sealed shut."<<endl;
                    this->Game::enter();
                    std::cout<<"'Do you know why you were brought here?' The woman asks"<<endl;
                    this->Game::enter();
                    char about_to_end;
                    std::cout<<"a) No"<<endl;
                    std::cout<<"Your choice: ", cin >> about_to_end, std::cout<<"\n"<<endl;

                    switch(about_to_end){
                        case 'a':
                            std::cout<<"'You're familiar with forest guardians.'"<<endl;
                            this->Game::enter();
                            std::cout<<"'Forest spirits. Everyone has their own version.'"<<endl; 
                            this->Game::enter();
                            std::cout<<"'They used to be kind, but humans continued to burn and destroy this planet.'"<<endl;
                            this->Game::enter();
                            std::cout<<"'As a result, forest demons now guard this world.'"<<endl; 
                            this->Game::enter();
                            std::cout<<"'We lure people like you in: we're tired of you'"<<endl;
                            this->Game::enter();
                            std::cout<<"You're now helplessly cornered on the couch, grotesque shadows dancing on the candlelit walls.\n\n\n"<<endl;
                            this->pauseprint(2000);
                            std::cout<<"Your heart beats faster and faster as they get closer.\n\n"<<endl; 
                            this->pauseprint(2000);
                            std::cout<<"One last prayer, and the candles go out.\n"<<endl;
                            this->Game::pauseprint(2000);

                            std::cout<<"======THE END======\n"<<endl;
                            this->set_complete();
                    }
            }
    } 
}


//
//This function starts the game off
//At any choice branch, the user can select q to quit to
//to the main menu, and thus start over
//
void Game::startgame(){
    bool continue_bool = true;
    while (continue_bool){
    std::cout<< "The night is dark and cloudy."<<endl;
    this->Game::enter();
    std::cout<<"The moon does its best to shine through the suffocating layer of clouds."<<endl;
    this->Game::enter();
    std::cout<<"You're the only car on the cold interstate, evergreen trees hugging the unfriendly road."<<endl;
    this->Game::enter();
    std::cout<<"You suddenly spot a dim light on the side of the road and slow down."<<endl;
    this->Game::enter();
    std::cout<<"It's a car, partially crushed against one of the sturdy trees." <<endl;
    this->Game::enter();
    char one;
    std::cout << "a) Pull over and inspect the scene"<<endl;
    std::cout<< "Your choice: ",cin >>one, std::cout<<"\n";
    
    switch (one){
        case 'q':
            std::cout<<"QUITTING"<<endl;
            continue_bool = false;
            break;
        case 'a':
            char two;
            std::cout << "You pull over and get out of your car to examine the wreckage"<<endl;
            this->Game::enter();
            std::cout<<"There's no sign of life, save a small screen glowing in the dark"<<endl;
            this->Game::enter();
            std::cout<<"It's a phone." <<endl;
            std::cout << "a) Pick the phone up"<<endl;
            std::cout <<"Your choice: ", cin>>two, std::cout<<"\n"<<endl;

            switch(two){
                case 'q':
                    std::cout<<"QUITTING"<<endl;
                    continue_bool = false;
                    break;
                case 'a':
                    char three;
                    std::cout<<"The phone is in perfectly good condition considering the crumpled state the car is in."<<endl;
                    this->Game::enter();
                    std::cout<<"Seconds after you pick it up, it buzzes"<<endl;
                    this->Game::enter();
                    std::cout<<"The screen lights up with a text."<<endl;
                    this->Game::enter();
                    std::cout<<"'Hello? i s aynyone theR? helpP me'" <<endl;
                    std::cout<<"a) Put the phone down and walk away, back to your car"<<endl;
                    std::cout<<"b) Text 'Who are you?'" <<endl;
                    std::cout<<"Your choice: ", cin >> three, std::cout<<"\n"<<endl;

                    switch(three){
                        case 'q':
                            std::cout<<"QUITTING"<<endl;
                            continue_bool = false;
                            break;
                        case 'a':
                            this->gameoverpath_car();
                            continue_bool = false;
                            break;
                        case 'b':
                            std::cout<<"'Almost immediately, you get a reply.'"<<endl;
                            this->Game::enter();
                            std::cout<<"'plase help m e. kidnapd'"<<endl;
                            this->Game::enter();
                            std::cout<<"'i can tell you wher i am plea Se hekp me!'"<<endl;
                            this->Game::enter();
                            std::cout<<"You text back."<<endl;
                            char four;
                            std::cout<<"a) Give me directions and I'll help you"<<endl;
                            std::cout<<"Your choice: ", cin >> four, std::cout<<"\n"<<endl;

                            switch (four){
                                case 'q':
                                    std::cout<<"QUITTING"<<endl;
                                    continue_bool = false;
                                    break;
                                case 'a':
                                std::cout<<"'She\'s gone now.'"<<endl;
                                this->Game::enter();
                                std::cout<<"'You'll have to trust me. I'm trusting you'"<<endl;
                                this->Game::enter();
                                std::cout<<"'It's so cold... you can probably hear the creek. Go towards it'"<<endl;
                                char five;
                                std::cout<<"a) Go towards the creek through a semi-clear path"<<endl;
                                std::cout<<"b) Go towards the creek through the forest"<<endl;
                                std::cout<<"Your choice: ", cin>>five, std::cout<<"\n"<<endl;
                                switch (five){
                                    case 'q':
                                        std::cout<<"QUITTING"<<endl;
                                        continue_bool = false;
                                        break;
                                    case 'a':
                                        this->forestpath_path();
                                        continue_bool = false;
                                        break;
                                    case 'b':
                                        this->gameoverpath_forest();
                                        continue_bool = false;
                                        break;
                                    break;
                                }
                            break;    
                            }
                        break;    
                    }
                break;
            }
    break;       
    }
    }
}
                        
                                

