//
//
//Game class to build and launch the playable game
//
#include <time.h>
#include <limits>
#include <iostream>


using namespace std;

class Game {
    public:
        void set_complete(){has_completed = true;} //Executed once the user reaches the end of the game
        void startgame(); //Starts the game
        void pauseprint(int millisec){ //This function is found in the game over paths and times the print executions for suspense
            clock_t time_end;
            time_end = clock() + millisec * CLOCKS_PER_SEC/1000;
            while (clock() < time_end)
            {
            }
        }
        void gameoverpath_car();
        void gameoverpath_forest();
        void forestpath_path();
        void enter(){ cin.ignore(std::numeric_limits<streamsize>::max(), '\n');}
        bool isComplete(){return has_completed;}

    private: bool has_completed = false;
};